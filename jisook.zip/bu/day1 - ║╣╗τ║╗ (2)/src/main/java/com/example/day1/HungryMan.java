package com.example.day1;

public class HungryMan {
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public void setAge(int age) {
        this.age = age;
    }

    private int age;
}
