package com.example.day1;

import org.springframework.context.ApplicationEvent;

public class MyEvent  {

    public int getData() {
        return data;
    }

    private int data;

    public MyEvent(int data) {
        this.data = data;
    }
}
