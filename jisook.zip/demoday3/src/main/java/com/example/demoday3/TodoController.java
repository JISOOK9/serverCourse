package com.example.demoday3;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static org.apache.tomcat.util.http.parser.MediaType.*;

@Controller
public class TodoController {

    Set<Todo> todos = new HashSet<>();

    @PostMapping("/todo")
    @ResponseBody
    public Todo createNewTodo(@RequestBody Todo todo) {
        todo.setDate(LocalDateTime.now());
        todos.add(todo);
        return todo;
    }

    @GetMapping("/todo/list")
    public String TodoListView(Model model) {
        Set<Todo> todoList = Set.of(
                new Todo("밥 먹기"),
                new Todo("잠 자기"),
                new Todo("방 정리"));
        model.addAttribute("todoList", todoList);
        model.addAttribute("noteNum", todoList.size());
        return "todo/list";
    }

/*    @GetMapping("/events**")
    public String EventView(Model model) {
        String eventResult = "당첨";
        model.addAttribute("result", eventResult);
        return "eventResult";
    }

    @GetMapping("/events/{id}")
    @ResponseBody
    public String getAnEvent(@PathVariable("id") int idV) {
        return "event";
    }



    @RequestMapping(method=RequestMethod.DELETE, value="/events/**")
    public String deleteEvent() {
        return "eventDelete";
    }*/

    @GetMapping("/events/{id}")
    @ResponseBody
    public Event getEvent(@PathVariable Long id) {
        Event event = new Event();
        event.setId(id);
        return event;
    }

    @PostMapping("/events/test")
    @ResponseBody
    public Event getEvent2(@RequestParam String name) {
        Event event = new Event();
        event.setEventName(name);
        return event;
    }
}
