package com.example.day1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
@EnableAspectJAutoProxy
public class MyConfig {

    /*@Autowired
    @Qualifier("optionalRepository")
    public BookRepository bookRepo;


    @Autowired
    public BookService bookService;*/

}
