package com.example.demoday3;

import java.time.LocalDateTime;
import java.util.Date;

public class Todo {

    private String note;
    private LocalDateTime date;

    public Todo(){

    }

    public Todo(String note){
        setNote(note);
    }
    public String getNote() {

        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }
}
