package com.example.day1;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class MyEventListener {

    @EventListener
    public void onApplicationEvent(MyEvent event) {
        System.out.println("Event data: " + event.getData());
    }
}
