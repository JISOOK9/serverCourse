package com.example.day1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    public BookService() {

    }

    public BookRepository getRepository() {
        return repository;
    }

    public void setRepository(BookRepository repository) {
        this.repository = repository;
    }

    public void sayHello(){
        System.out.println("It`s the end of today`s class!!");
    }
    @Autowired
    @Qualifier("optionalRepository")
    private BookRepository repository;
}
