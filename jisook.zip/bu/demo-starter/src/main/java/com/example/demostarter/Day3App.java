package com.example.demostarter;

import com.example.day1.HungryMan;
import com.example.day1.HungryManProp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Day3App {

    @Autowired
    HungryMan man;

    @Bean
    public ApplicationRunner applicationRunner() {
        return args-> {

                    System.out.println(man.getAge());
                    System.out.println(man.getName());
        };
    }

    @Bean
    public HungryMan getManNew(){
        HungryManProp prop = new HungryManProp();
        HungryMan man = new HungryMan();
        man.setName(prop.getName());
        man.setAge(10);
        return man;
    }

    public static void main(String[] args) {
        SpringApplication.run(Day3App.class, args);
    }


}
