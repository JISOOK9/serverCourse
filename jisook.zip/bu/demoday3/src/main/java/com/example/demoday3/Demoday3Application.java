package com.example.demoday3;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class Demoday3Application {

/*
    @Value("${app.appName}")
    private String appName;

    @Value("${app.userName}")
    private String userName;

    @Autowired
    public AppProp appProp;

    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Bean
    public ApplicationRunner applicationRunner() {
        return args-> {
            logger.info("AppName : {}", appProp.getAppName());
            logger.debug("UserName : {}", appProp.getUserName());

        };
    }
*/

    public static void main(String[] args) {
        SpringApplication.run(Demoday3Application.class, args);
    }

    @RestController
    class HelloController{
        @Autowired
        HelloService helloService;

        @GetMapping("/hello")
        public String hello(){
            return "hello " + helloService.getName();
        }


    }

    @Service
    public class HelloService{
        private String getName() {
            return "Jisook";
        }

        public void setName(String name) {
            this.name = name;
        }

        public String name;

    }
}
