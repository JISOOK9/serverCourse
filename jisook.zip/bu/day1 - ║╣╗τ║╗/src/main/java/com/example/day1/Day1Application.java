package com.example.day1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

import java.lang.reflect.Proxy;
import java.util.Arrays;

@SpringBootApplication
public class Day1Application {

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
        /*ApplicationEventPublisher eventPub = new AnnotationConfigApplicationContext(MyConfig.class);
        eventPub.publishEvent(new MyEvent(100));*/


        BookService service = context.getBean(BookService.class);
        service.sayHello();
        /*Environment env = context.getEnvironment();

        System.out.println(env.getProperty("app.name"));
        System.out.println(Arrays.toString(env.getActiveProfiles()));
*/
        //System.out.print(context.getBean(BookRepository.class).getClass());

        /*
        System.out.println(env.getActiveProfiles().toString());
        System.out.println(service);
        System.out.println(context.getBean(OptionalRepository.class));
        System.out.println(service.getRepository());
*/        //SpringApplication.run(Day1Application.class, args);
    }
}
