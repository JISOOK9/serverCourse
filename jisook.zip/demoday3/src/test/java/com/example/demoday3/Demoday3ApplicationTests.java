package com.example.demoday3;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Set;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
//@TestPropertySource(locations = "classpath:/test.properties")
public class Demoday3ApplicationTests {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    @Test
    public void createTodo() throws Exception {
        Todo todo = new Todo();
        todo.setNote("free note");
        String todoJson = objectMapper.writeValueAsString(todo);

        mockMvc.perform(post("/todo")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(todoJson))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.note",
                        Matchers.equalToIgnoringCase("free note")));
    }

/*    @Test
    public void createTodoList() throws Exception {
        Set<Todo> todoList = Set.of(
                new Todo("밥 먹기"),
                new Todo("잠 자기"),
                new Todo("방 정리"));

        String todoJson = objectMapper.writeValueAsString(todoList);
        System.out.println(todoJson);
        mockMvc.perform(get("/todo/list")
                .andDo(print()));

    }*/


    @Test
    public void getEvents() throws Exception {

        mockMvc.perform(get("/events/1"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    public void getEvent2() throws Exception {
        mockMvc.perform(post("/events/test")
        .param("name", "christmas event"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.eventName").value("christmas event"));

    }

}
