package com.example.day1;

public interface BookRepository {
}
