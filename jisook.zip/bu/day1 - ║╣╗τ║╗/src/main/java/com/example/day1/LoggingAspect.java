package com.example.day1;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import static org.aspectj.lang.ProceedingJoinPoint.*;

@Aspect
@Component
public class LoggingAspect {
    @Around("execution(* com.example.day1.BookService.*(..))")
    public void greeting(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        System.out.println("hello");
        proceedingJoinPoint.proceed();
        System.out.println("bye");
    }
}

