package com.example.day1;

import org.springframework.boot.context.properties.ConfigurationProperties;

//property에서 무슨 프리픽스 쓸건지 설정 ex-prefix.값이름
@ConfigurationProperties(prefix = "hm")
public class HungryManProp {
    private String name = "defaultName";
    private int age = 0;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
