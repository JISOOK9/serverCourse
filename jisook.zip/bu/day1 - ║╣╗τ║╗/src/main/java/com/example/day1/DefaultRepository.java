package com.example.day1;

import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

@Repository
@Profile("dev")
public class DefaultRepository implements BookRepository {

    public DefaultRepository() {
    }
}
