package com.example.day1;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(HungryManProp.class)
public class HungryManConfig {

    @Bean
    @ConditionalOnMissingBean
    public HungryMan getManOrg(HungryManProp prop){
        HungryMan man = new HungryMan();
        man.setAge(prop.getAge());
        man.setName(prop.getName());
        return man;
    }

}
